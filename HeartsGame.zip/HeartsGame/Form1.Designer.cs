﻿namespace HeartsGame
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.My_Score = new System.Windows.Forms.Label();
            this.Player2_Score = new System.Windows.Forms.Label();
            this.Player3_Score = new System.Windows.Forms.Label();
            this.Player4_Score = new System.Windows.Forms.Label();
            this.panel_P3 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.pbP3_1 = new System.Windows.Forms.PictureBox();
            this.pbP3_2 = new System.Windows.Forms.PictureBox();
            this.pbP3_3 = new System.Windows.Forms.PictureBox();
            this.pbP3_4 = new System.Windows.Forms.PictureBox();
            this.pbP3_5 = new System.Windows.Forms.PictureBox();
            this.pbP3_6 = new System.Windows.Forms.PictureBox();
            this.pbP3_7 = new System.Windows.Forms.PictureBox();
            this.pbP3_8 = new System.Windows.Forms.PictureBox();
            this.pbP3_9 = new System.Windows.Forms.PictureBox();
            this.pbP3_10 = new System.Windows.Forms.PictureBox();
            this.pbP3_11 = new System.Windows.Forms.PictureBox();
            this.pbP3_12 = new System.Windows.Forms.PictureBox();
            this.pbP3_13 = new System.Windows.Forms.PictureBox();
            this.panel_P2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.pbP2_12 = new System.Windows.Forms.PictureBox();
            this.pbP2_11 = new System.Windows.Forms.PictureBox();
            this.pbP2_10 = new System.Windows.Forms.PictureBox();
            this.pbP2_9 = new System.Windows.Forms.PictureBox();
            this.pbP2_8 = new System.Windows.Forms.PictureBox();
            this.pbP2_7 = new System.Windows.Forms.PictureBox();
            this.pbP2_6 = new System.Windows.Forms.PictureBox();
            this.pbP2_5 = new System.Windows.Forms.PictureBox();
            this.pbP2_4 = new System.Windows.Forms.PictureBox();
            this.pbP2_3 = new System.Windows.Forms.PictureBox();
            this.pbP2_2 = new System.Windows.Forms.PictureBox();
            this.pbP2_1 = new System.Windows.Forms.PictureBox();
            this.pbP2_13 = new System.Windows.Forms.PictureBox();
            this.panel_P1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.pbMe13 = new System.Windows.Forms.PictureBox();
            this.pbMe12 = new System.Windows.Forms.PictureBox();
            this.pbMe11 = new System.Windows.Forms.PictureBox();
            this.pbMe10 = new System.Windows.Forms.PictureBox();
            this.pbMe9 = new System.Windows.Forms.PictureBox();
            this.pbMe8 = new System.Windows.Forms.PictureBox();
            this.pbMe7 = new System.Windows.Forms.PictureBox();
            this.pbMe6 = new System.Windows.Forms.PictureBox();
            this.pbMe5 = new System.Windows.Forms.PictureBox();
            this.pbMe4 = new System.Windows.Forms.PictureBox();
            this.pbMe3 = new System.Windows.Forms.PictureBox();
            this.pbMe2 = new System.Windows.Forms.PictureBox();
            this.pbMe1 = new System.Windows.Forms.PictureBox();
            this.panel_P4 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.pbP4_13 = new System.Windows.Forms.PictureBox();
            this.pbP4_12 = new System.Windows.Forms.PictureBox();
            this.pbP4_11 = new System.Windows.Forms.PictureBox();
            this.pbP4_10 = new System.Windows.Forms.PictureBox();
            this.pbP4_9 = new System.Windows.Forms.PictureBox();
            this.pbP4_8 = new System.Windows.Forms.PictureBox();
            this.pbP4_7 = new System.Windows.Forms.PictureBox();
            this.pbP4_6 = new System.Windows.Forms.PictureBox();
            this.pbP4_5 = new System.Windows.Forms.PictureBox();
            this.pbP4_4 = new System.Windows.Forms.PictureBox();
            this.pbP4_3 = new System.Windows.Forms.PictureBox();
            this.pbP4_1 = new System.Windows.Forms.PictureBox();
            this.pbP4_2 = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.Player2trick = new System.Windows.Forms.PictureBox();
            this.Player3trick = new System.Windows.Forms.PictureBox();
            this.mytrick = new System.Windows.Forms.PictureBox();
            this.Player4trick = new System.Windows.Forms.PictureBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.Deck = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.restartButton = new System.Windows.Forms.Button();
            this.panel_P3.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbP3_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP3_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP3_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP3_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP3_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP3_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP3_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP3_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP3_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP3_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP3_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP3_12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP3_13)).BeginInit();
            this.panel_P2.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbP2_12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP2_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP2_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP2_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP2_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP2_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP2_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP2_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP2_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP2_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP2_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP2_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP2_13)).BeginInit();
            this.panel_P1.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbMe13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMe12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMe11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMe10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMe9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMe8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMe7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMe6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMe5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMe4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMe3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMe2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMe1)).BeginInit();
            this.panel_P4.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbP4_13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP4_12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP4_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP4_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP4_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP4_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP4_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP4_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP4_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP4_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP4_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP4_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP4_2)).BeginInit();
            this.panel5.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Player2trick)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Player3trick)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mytrick)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Player4trick)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Deck)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(613, 663);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "ME";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 349);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "Player 2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(613, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 16);
            this.label3.TabIndex = 6;
            this.label3.Text = "Player 3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(984, 370);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 16);
            this.label4.TabIndex = 7;
            this.label4.Text = "Player 4";
            // 
            // My_Score
            // 
            this.My_Score.AutoSize = true;
            this.My_Score.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.My_Score.ForeColor = System.Drawing.Color.White;
            this.My_Score.Location = new System.Drawing.Point(613, 679);
            this.My_Score.Name = "My_Score";
            this.My_Score.Size = new System.Drawing.Size(79, 16);
            this.My_Score.TabIndex = 8;
            this.My_Score.Text = "Points - 00";
            // 
            // Player2_Score
            // 
            this.Player2_Score.AutoSize = true;
            this.Player2_Score.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Player2_Score.ForeColor = System.Drawing.Color.White;
            this.Player2_Score.Location = new System.Drawing.Point(12, 365);
            this.Player2_Score.Name = "Player2_Score";
            this.Player2_Score.Size = new System.Drawing.Size(79, 16);
            this.Player2_Score.TabIndex = 9;
            this.Player2_Score.Text = "Points - 00";
            // 
            // Player3_Score
            // 
            this.Player3_Score.AutoSize = true;
            this.Player3_Score.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Player3_Score.ForeColor = System.Drawing.Color.White;
            this.Player3_Score.Location = new System.Drawing.Point(613, 28);
            this.Player3_Score.Name = "Player3_Score";
            this.Player3_Score.Size = new System.Drawing.Size(79, 16);
            this.Player3_Score.TabIndex = 10;
            this.Player3_Score.Text = "Points - 00";
            // 
            // Player4_Score
            // 
            this.Player4_Score.AutoSize = true;
            this.Player4_Score.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Player4_Score.ForeColor = System.Drawing.Color.White;
            this.Player4_Score.Location = new System.Drawing.Point(984, 386);
            this.Player4_Score.Name = "Player4_Score";
            this.Player4_Score.Size = new System.Drawing.Size(79, 16);
            this.Player4_Score.TabIndex = 11;
            this.Player4_Score.Text = "Points - 00";
            // 
            // panel_P3
            // 
            this.panel_P3.Controls.Add(this.tableLayoutPanel3);
            this.panel_P3.Location = new System.Drawing.Point(507, 68);
            this.panel_P3.Name = "panel_P3";
            this.panel_P3.Size = new System.Drawing.Size(356, 100);
            this.panel_P3.TabIndex = 12;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 13;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel3.Controls.Add(this.pbP3_1, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.pbP3_2, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.pbP3_3, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.pbP3_4, 3, 0);
            this.tableLayoutPanel3.Controls.Add(this.pbP3_5, 4, 0);
            this.tableLayoutPanel3.Controls.Add(this.pbP3_6, 5, 0);
            this.tableLayoutPanel3.Controls.Add(this.pbP3_7, 6, 0);
            this.tableLayoutPanel3.Controls.Add(this.pbP3_8, 7, 0);
            this.tableLayoutPanel3.Controls.Add(this.pbP3_9, 8, 0);
            this.tableLayoutPanel3.Controls.Add(this.pbP3_10, 9, 0);
            this.tableLayoutPanel3.Controls.Add(this.pbP3_11, 10, 0);
            this.tableLayoutPanel3.Controls.Add(this.pbP3_12, 11, 0);
            this.tableLayoutPanel3.Controls.Add(this.pbP3_13, 12, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(356, 100);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // pbP3_1
            // 
            this.pbP3_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP3_1.Location = new System.Drawing.Point(3, 3);
            this.pbP3_1.Name = "pbP3_1";
            this.pbP3_1.Size = new System.Drawing.Size(21, 94);
            this.pbP3_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP3_1.TabIndex = 0;
            this.pbP3_1.TabStop = false;
            // 
            // pbP3_2
            // 
            this.pbP3_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP3_2.Location = new System.Drawing.Point(30, 3);
            this.pbP3_2.Name = "pbP3_2";
            this.pbP3_2.Size = new System.Drawing.Size(21, 94);
            this.pbP3_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP3_2.TabIndex = 1;
            this.pbP3_2.TabStop = false;
            // 
            // pbP3_3
            // 
            this.pbP3_3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP3_3.Location = new System.Drawing.Point(57, 3);
            this.pbP3_3.Name = "pbP3_3";
            this.pbP3_3.Size = new System.Drawing.Size(21, 94);
            this.pbP3_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP3_3.TabIndex = 2;
            this.pbP3_3.TabStop = false;
            // 
            // pbP3_4
            // 
            this.pbP3_4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP3_4.Location = new System.Drawing.Point(84, 3);
            this.pbP3_4.Name = "pbP3_4";
            this.pbP3_4.Size = new System.Drawing.Size(21, 94);
            this.pbP3_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP3_4.TabIndex = 3;
            this.pbP3_4.TabStop = false;
            // 
            // pbP3_5
            // 
            this.pbP3_5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP3_5.Location = new System.Drawing.Point(111, 3);
            this.pbP3_5.Name = "pbP3_5";
            this.pbP3_5.Size = new System.Drawing.Size(21, 94);
            this.pbP3_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP3_5.TabIndex = 4;
            this.pbP3_5.TabStop = false;
            // 
            // pbP3_6
            // 
            this.pbP3_6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP3_6.Location = new System.Drawing.Point(138, 3);
            this.pbP3_6.Name = "pbP3_6";
            this.pbP3_6.Size = new System.Drawing.Size(21, 94);
            this.pbP3_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP3_6.TabIndex = 5;
            this.pbP3_6.TabStop = false;
            // 
            // pbP3_7
            // 
            this.pbP3_7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP3_7.Location = new System.Drawing.Point(165, 3);
            this.pbP3_7.Name = "pbP3_7";
            this.pbP3_7.Size = new System.Drawing.Size(21, 94);
            this.pbP3_7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP3_7.TabIndex = 6;
            this.pbP3_7.TabStop = false;
            // 
            // pbP3_8
            // 
            this.pbP3_8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP3_8.Location = new System.Drawing.Point(192, 3);
            this.pbP3_8.Name = "pbP3_8";
            this.pbP3_8.Size = new System.Drawing.Size(21, 94);
            this.pbP3_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP3_8.TabIndex = 7;
            this.pbP3_8.TabStop = false;
            // 
            // pbP3_9
            // 
            this.pbP3_9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP3_9.Location = new System.Drawing.Point(219, 3);
            this.pbP3_9.Name = "pbP3_9";
            this.pbP3_9.Size = new System.Drawing.Size(21, 94);
            this.pbP3_9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP3_9.TabIndex = 8;
            this.pbP3_9.TabStop = false;
            // 
            // pbP3_10
            // 
            this.pbP3_10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP3_10.Location = new System.Drawing.Point(246, 3);
            this.pbP3_10.Name = "pbP3_10";
            this.pbP3_10.Size = new System.Drawing.Size(21, 94);
            this.pbP3_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP3_10.TabIndex = 9;
            this.pbP3_10.TabStop = false;
            // 
            // pbP3_11
            // 
            this.pbP3_11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP3_11.Location = new System.Drawing.Point(273, 3);
            this.pbP3_11.Name = "pbP3_11";
            this.pbP3_11.Size = new System.Drawing.Size(21, 94);
            this.pbP3_11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP3_11.TabIndex = 10;
            this.pbP3_11.TabStop = false;
            // 
            // pbP3_12
            // 
            this.pbP3_12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP3_12.Location = new System.Drawing.Point(300, 3);
            this.pbP3_12.Name = "pbP3_12";
            this.pbP3_12.Size = new System.Drawing.Size(21, 94);
            this.pbP3_12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP3_12.TabIndex = 11;
            this.pbP3_12.TabStop = false;
            // 
            // pbP3_13
            // 
            this.pbP3_13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP3_13.Location = new System.Drawing.Point(327, 3);
            this.pbP3_13.Name = "pbP3_13";
            this.pbP3_13.Size = new System.Drawing.Size(26, 94);
            this.pbP3_13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP3_13.TabIndex = 12;
            this.pbP3_13.TabStop = false;
            // 
            // panel_P2
            // 
            this.panel_P2.Controls.Add(this.tableLayoutPanel2);
            this.panel_P2.Location = new System.Drawing.Point(15, 190);
            this.panel_P2.Name = "panel_P2";
            this.panel_P2.Size = new System.Drawing.Size(356, 100);
            this.panel_P2.TabIndex = 13;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 13;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel2.Controls.Add(this.pbP2_12, 11, 0);
            this.tableLayoutPanel2.Controls.Add(this.pbP2_11, 10, 0);
            this.tableLayoutPanel2.Controls.Add(this.pbP2_10, 9, 0);
            this.tableLayoutPanel2.Controls.Add(this.pbP2_9, 8, 0);
            this.tableLayoutPanel2.Controls.Add(this.pbP2_8, 7, 0);
            this.tableLayoutPanel2.Controls.Add(this.pbP2_7, 6, 0);
            this.tableLayoutPanel2.Controls.Add(this.pbP2_6, 5, 0);
            this.tableLayoutPanel2.Controls.Add(this.pbP2_5, 4, 0);
            this.tableLayoutPanel2.Controls.Add(this.pbP2_4, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.pbP2_3, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.pbP2_2, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.pbP2_1, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.pbP2_13, 12, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(356, 100);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // pbP2_12
            // 
            this.pbP2_12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP2_12.Location = new System.Drawing.Point(300, 3);
            this.pbP2_12.Name = "pbP2_12";
            this.pbP2_12.Size = new System.Drawing.Size(21, 94);
            this.pbP2_12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP2_12.TabIndex = 12;
            this.pbP2_12.TabStop = false;
            // 
            // pbP2_11
            // 
            this.pbP2_11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP2_11.Location = new System.Drawing.Point(273, 3);
            this.pbP2_11.Name = "pbP2_11";
            this.pbP2_11.Size = new System.Drawing.Size(21, 94);
            this.pbP2_11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP2_11.TabIndex = 11;
            this.pbP2_11.TabStop = false;
            // 
            // pbP2_10
            // 
            this.pbP2_10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP2_10.Location = new System.Drawing.Point(246, 3);
            this.pbP2_10.Name = "pbP2_10";
            this.pbP2_10.Size = new System.Drawing.Size(21, 94);
            this.pbP2_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP2_10.TabIndex = 10;
            this.pbP2_10.TabStop = false;
            // 
            // pbP2_9
            // 
            this.pbP2_9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP2_9.Location = new System.Drawing.Point(219, 3);
            this.pbP2_9.Name = "pbP2_9";
            this.pbP2_9.Size = new System.Drawing.Size(21, 94);
            this.pbP2_9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP2_9.TabIndex = 9;
            this.pbP2_9.TabStop = false;
            // 
            // pbP2_8
            // 
            this.pbP2_8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP2_8.Location = new System.Drawing.Point(192, 3);
            this.pbP2_8.Name = "pbP2_8";
            this.pbP2_8.Size = new System.Drawing.Size(21, 94);
            this.pbP2_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP2_8.TabIndex = 8;
            this.pbP2_8.TabStop = false;
            // 
            // pbP2_7
            // 
            this.pbP2_7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP2_7.Location = new System.Drawing.Point(165, 3);
            this.pbP2_7.Name = "pbP2_7";
            this.pbP2_7.Size = new System.Drawing.Size(21, 94);
            this.pbP2_7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP2_7.TabIndex = 7;
            this.pbP2_7.TabStop = false;
            // 
            // pbP2_6
            // 
            this.pbP2_6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP2_6.Location = new System.Drawing.Point(138, 3);
            this.pbP2_6.Name = "pbP2_6";
            this.pbP2_6.Size = new System.Drawing.Size(21, 94);
            this.pbP2_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP2_6.TabIndex = 6;
            this.pbP2_6.TabStop = false;
            // 
            // pbP2_5
            // 
            this.pbP2_5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP2_5.Location = new System.Drawing.Point(111, 3);
            this.pbP2_5.Name = "pbP2_5";
            this.pbP2_5.Size = new System.Drawing.Size(21, 94);
            this.pbP2_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP2_5.TabIndex = 5;
            this.pbP2_5.TabStop = false;
            // 
            // pbP2_4
            // 
            this.pbP2_4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP2_4.Location = new System.Drawing.Point(84, 3);
            this.pbP2_4.Name = "pbP2_4";
            this.pbP2_4.Size = new System.Drawing.Size(21, 94);
            this.pbP2_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP2_4.TabIndex = 4;
            this.pbP2_4.TabStop = false;
            // 
            // pbP2_3
            // 
            this.pbP2_3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP2_3.Location = new System.Drawing.Point(57, 3);
            this.pbP2_3.Name = "pbP2_3";
            this.pbP2_3.Size = new System.Drawing.Size(21, 94);
            this.pbP2_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP2_3.TabIndex = 3;
            this.pbP2_3.TabStop = false;
            // 
            // pbP2_2
            // 
            this.pbP2_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP2_2.Location = new System.Drawing.Point(30, 3);
            this.pbP2_2.Name = "pbP2_2";
            this.pbP2_2.Size = new System.Drawing.Size(21, 94);
            this.pbP2_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP2_2.TabIndex = 2;
            this.pbP2_2.TabStop = false;
            // 
            // pbP2_1
            // 
            this.pbP2_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP2_1.Location = new System.Drawing.Point(3, 3);
            this.pbP2_1.Name = "pbP2_1";
            this.pbP2_1.Size = new System.Drawing.Size(21, 94);
            this.pbP2_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP2_1.TabIndex = 1;
            this.pbP2_1.TabStop = false;
            // 
            // pbP2_13
            // 
            this.pbP2_13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP2_13.Location = new System.Drawing.Point(327, 3);
            this.pbP2_13.Name = "pbP2_13";
            this.pbP2_13.Size = new System.Drawing.Size(26, 94);
            this.pbP2_13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP2_13.TabIndex = 0;
            this.pbP2_13.TabStop = false;
            // 
            // panel_P1
            // 
            this.panel_P1.Controls.Add(this.tableLayoutPanel5);
            this.panel_P1.Location = new System.Drawing.Point(180, 556);
            this.panel_P1.Name = "panel_P1";
            this.panel_P1.Size = new System.Drawing.Size(786, 104);
            this.panel_P1.TabIndex = 14;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 13;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel5.Controls.Add(this.pbMe13, 12, 0);
            this.tableLayoutPanel5.Controls.Add(this.pbMe12, 11, 0);
            this.tableLayoutPanel5.Controls.Add(this.pbMe11, 10, 0);
            this.tableLayoutPanel5.Controls.Add(this.pbMe10, 9, 0);
            this.tableLayoutPanel5.Controls.Add(this.pbMe9, 8, 0);
            this.tableLayoutPanel5.Controls.Add(this.pbMe8, 7, 0);
            this.tableLayoutPanel5.Controls.Add(this.pbMe7, 6, 0);
            this.tableLayoutPanel5.Controls.Add(this.pbMe6, 5, 0);
            this.tableLayoutPanel5.Controls.Add(this.pbMe5, 4, 0);
            this.tableLayoutPanel5.Controls.Add(this.pbMe4, 3, 0);
            this.tableLayoutPanel5.Controls.Add(this.pbMe3, 2, 0);
            this.tableLayoutPanel5.Controls.Add(this.pbMe2, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.pbMe1, 0, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel5.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(786, 104);
            this.tableLayoutPanel5.TabIndex = 1;
            this.tableLayoutPanel5.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel5_Paint);
            // 
            // pbMe13
            // 
            this.pbMe13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbMe13.Location = new System.Drawing.Point(720, 0);
            this.pbMe13.Margin = new System.Windows.Forms.Padding(0);
            this.pbMe13.Name = "pbMe13";
            this.pbMe13.Size = new System.Drawing.Size(66, 104);
            this.pbMe13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbMe13.TabIndex = 13;
            this.pbMe13.TabStop = false;
            this.pbMe13.Click += new System.EventHandler(this.pictureBox43_Click);
            // 
            // pbMe12
            // 
            this.pbMe12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbMe12.Location = new System.Drawing.Point(660, 0);
            this.pbMe12.Margin = new System.Windows.Forms.Padding(0);
            this.pbMe12.Name = "pbMe12";
            this.pbMe12.Size = new System.Drawing.Size(60, 104);
            this.pbMe12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbMe12.TabIndex = 12;
            this.pbMe12.TabStop = false;
            this.pbMe12.Click += new System.EventHandler(this.pictureBox42_Click);
            // 
            // pbMe11
            // 
            this.pbMe11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbMe11.Location = new System.Drawing.Point(600, 0);
            this.pbMe11.Margin = new System.Windows.Forms.Padding(0);
            this.pbMe11.Name = "pbMe11";
            this.pbMe11.Size = new System.Drawing.Size(60, 104);
            this.pbMe11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbMe11.TabIndex = 11;
            this.pbMe11.TabStop = false;
            this.pbMe11.Click += new System.EventHandler(this.pictureBox41_Click);
            // 
            // pbMe10
            // 
            this.pbMe10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbMe10.Location = new System.Drawing.Point(540, 0);
            this.pbMe10.Margin = new System.Windows.Forms.Padding(0);
            this.pbMe10.Name = "pbMe10";
            this.pbMe10.Size = new System.Drawing.Size(60, 104);
            this.pbMe10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbMe10.TabIndex = 10;
            this.pbMe10.TabStop = false;
            this.pbMe10.Click += new System.EventHandler(this.pictureBox40_Click);
            // 
            // pbMe9
            // 
            this.pbMe9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbMe9.Location = new System.Drawing.Point(480, 0);
            this.pbMe9.Margin = new System.Windows.Forms.Padding(0);
            this.pbMe9.Name = "pbMe9";
            this.pbMe9.Size = new System.Drawing.Size(60, 104);
            this.pbMe9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbMe9.TabIndex = 9;
            this.pbMe9.TabStop = false;
            this.pbMe9.Click += new System.EventHandler(this.pictureBox39_Click);
            // 
            // pbMe8
            // 
            this.pbMe8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbMe8.Location = new System.Drawing.Point(420, 0);
            this.pbMe8.Margin = new System.Windows.Forms.Padding(0);
            this.pbMe8.Name = "pbMe8";
            this.pbMe8.Size = new System.Drawing.Size(60, 104);
            this.pbMe8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbMe8.TabIndex = 8;
            this.pbMe8.TabStop = false;
            this.pbMe8.Click += new System.EventHandler(this.pictureBox38_Click);
            // 
            // pbMe7
            // 
            this.pbMe7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbMe7.Location = new System.Drawing.Point(360, 0);
            this.pbMe7.Margin = new System.Windows.Forms.Padding(0);
            this.pbMe7.Name = "pbMe7";
            this.pbMe7.Size = new System.Drawing.Size(60, 104);
            this.pbMe7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbMe7.TabIndex = 7;
            this.pbMe7.TabStop = false;
            this.pbMe7.Click += new System.EventHandler(this.pictureBox37_Click);
            // 
            // pbMe6
            // 
            this.pbMe6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbMe6.Location = new System.Drawing.Point(300, 0);
            this.pbMe6.Margin = new System.Windows.Forms.Padding(0);
            this.pbMe6.Name = "pbMe6";
            this.pbMe6.Size = new System.Drawing.Size(60, 104);
            this.pbMe6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbMe6.TabIndex = 6;
            this.pbMe6.TabStop = false;
            this.pbMe6.Click += new System.EventHandler(this.pictureBox36_Click);
            // 
            // pbMe5
            // 
            this.pbMe5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbMe5.Location = new System.Drawing.Point(240, 0);
            this.pbMe5.Margin = new System.Windows.Forms.Padding(0);
            this.pbMe5.Name = "pbMe5";
            this.pbMe5.Size = new System.Drawing.Size(60, 104);
            this.pbMe5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbMe5.TabIndex = 5;
            this.pbMe5.TabStop = false;
            this.pbMe5.Click += new System.EventHandler(this.pictureBox35_Click);
            // 
            // pbMe4
            // 
            this.pbMe4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbMe4.Location = new System.Drawing.Point(180, 0);
            this.pbMe4.Margin = new System.Windows.Forms.Padding(0);
            this.pbMe4.Name = "pbMe4";
            this.pbMe4.Size = new System.Drawing.Size(60, 104);
            this.pbMe4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbMe4.TabIndex = 4;
            this.pbMe4.TabStop = false;
            this.pbMe4.Click += new System.EventHandler(this.pictureBox34_Click);
            // 
            // pbMe3
            // 
            this.pbMe3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbMe3.Location = new System.Drawing.Point(120, 0);
            this.pbMe3.Margin = new System.Windows.Forms.Padding(0);
            this.pbMe3.Name = "pbMe3";
            this.pbMe3.Size = new System.Drawing.Size(60, 104);
            this.pbMe3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbMe3.TabIndex = 3;
            this.pbMe3.TabStop = false;
            this.pbMe3.Click += new System.EventHandler(this.pictureBox33_Click);
            // 
            // pbMe2
            // 
            this.pbMe2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbMe2.Location = new System.Drawing.Point(60, 0);
            this.pbMe2.Margin = new System.Windows.Forms.Padding(0);
            this.pbMe2.Name = "pbMe2";
            this.pbMe2.Size = new System.Drawing.Size(60, 104);
            this.pbMe2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbMe2.TabIndex = 2;
            this.pbMe2.TabStop = false;
            this.pbMe2.Click += new System.EventHandler(this.pictureBox32_Click);
            // 
            // pbMe1
            // 
            this.pbMe1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbMe1.Location = new System.Drawing.Point(0, 0);
            this.pbMe1.Margin = new System.Windows.Forms.Padding(0);
            this.pbMe1.Name = "pbMe1";
            this.pbMe1.Size = new System.Drawing.Size(60, 104);
            this.pbMe1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbMe1.TabIndex = 1;
            this.pbMe1.TabStop = false;
            this.pbMe1.Click += new System.EventHandler(this.pictureBox31_Click);
            // 
            // panel_P4
            // 
            this.panel_P4.Controls.Add(this.tableLayoutPanel4);
            this.panel_P4.Location = new System.Drawing.Point(731, 405);
            this.panel_P4.Name = "panel_P4";
            this.panel_P4.Size = new System.Drawing.Size(356, 100);
            this.panel_P4.TabIndex = 15;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 13;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel4.Controls.Add(this.pbP4_13, 12, 0);
            this.tableLayoutPanel4.Controls.Add(this.pbP4_12, 11, 0);
            this.tableLayoutPanel4.Controls.Add(this.pbP4_11, 10, 0);
            this.tableLayoutPanel4.Controls.Add(this.pbP4_10, 9, 0);
            this.tableLayoutPanel4.Controls.Add(this.pbP4_9, 8, 0);
            this.tableLayoutPanel4.Controls.Add(this.pbP4_8, 7, 0);
            this.tableLayoutPanel4.Controls.Add(this.pbP4_7, 6, 0);
            this.tableLayoutPanel4.Controls.Add(this.pbP4_6, 5, 0);
            this.tableLayoutPanel4.Controls.Add(this.pbP4_5, 4, 0);
            this.tableLayoutPanel4.Controls.Add(this.pbP4_4, 3, 0);
            this.tableLayoutPanel4.Controls.Add(this.pbP4_3, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.pbP4_1, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.pbP4_2, 1, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(356, 100);
            this.tableLayoutPanel4.TabIndex = 1;
            // 
            // pbP4_13
            // 
            this.pbP4_13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP4_13.Location = new System.Drawing.Point(327, 3);
            this.pbP4_13.Name = "pbP4_13";
            this.pbP4_13.Size = new System.Drawing.Size(26, 94);
            this.pbP4_13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP4_13.TabIndex = 13;
            this.pbP4_13.TabStop = false;
            // 
            // pbP4_12
            // 
            this.pbP4_12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP4_12.Location = new System.Drawing.Point(300, 3);
            this.pbP4_12.Name = "pbP4_12";
            this.pbP4_12.Size = new System.Drawing.Size(21, 94);
            this.pbP4_12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP4_12.TabIndex = 12;
            this.pbP4_12.TabStop = false;
            // 
            // pbP4_11
            // 
            this.pbP4_11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP4_11.Location = new System.Drawing.Point(273, 3);
            this.pbP4_11.Name = "pbP4_11";
            this.pbP4_11.Size = new System.Drawing.Size(21, 94);
            this.pbP4_11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP4_11.TabIndex = 11;
            this.pbP4_11.TabStop = false;
            // 
            // pbP4_10
            // 
            this.pbP4_10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP4_10.Location = new System.Drawing.Point(246, 3);
            this.pbP4_10.Name = "pbP4_10";
            this.pbP4_10.Size = new System.Drawing.Size(21, 94);
            this.pbP4_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP4_10.TabIndex = 10;
            this.pbP4_10.TabStop = false;
            // 
            // pbP4_9
            // 
            this.pbP4_9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP4_9.Location = new System.Drawing.Point(219, 3);
            this.pbP4_9.Name = "pbP4_9";
            this.pbP4_9.Size = new System.Drawing.Size(21, 94);
            this.pbP4_9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP4_9.TabIndex = 9;
            this.pbP4_9.TabStop = false;
            // 
            // pbP4_8
            // 
            this.pbP4_8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP4_8.Location = new System.Drawing.Point(192, 3);
            this.pbP4_8.Name = "pbP4_8";
            this.pbP4_8.Size = new System.Drawing.Size(21, 94);
            this.pbP4_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP4_8.TabIndex = 8;
            this.pbP4_8.TabStop = false;
            // 
            // pbP4_7
            // 
            this.pbP4_7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP4_7.Location = new System.Drawing.Point(165, 3);
            this.pbP4_7.Name = "pbP4_7";
            this.pbP4_7.Size = new System.Drawing.Size(21, 94);
            this.pbP4_7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP4_7.TabIndex = 7;
            this.pbP4_7.TabStop = false;
            // 
            // pbP4_6
            // 
            this.pbP4_6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP4_6.Location = new System.Drawing.Point(138, 3);
            this.pbP4_6.Name = "pbP4_6";
            this.pbP4_6.Size = new System.Drawing.Size(21, 94);
            this.pbP4_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP4_6.TabIndex = 6;
            this.pbP4_6.TabStop = false;
            // 
            // pbP4_5
            // 
            this.pbP4_5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP4_5.Location = new System.Drawing.Point(111, 3);
            this.pbP4_5.Name = "pbP4_5";
            this.pbP4_5.Size = new System.Drawing.Size(21, 94);
            this.pbP4_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP4_5.TabIndex = 5;
            this.pbP4_5.TabStop = false;
            this.pbP4_5.Click += new System.EventHandler(this.pictureBox48_Click);
            // 
            // pbP4_4
            // 
            this.pbP4_4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP4_4.Location = new System.Drawing.Point(84, 3);
            this.pbP4_4.Name = "pbP4_4";
            this.pbP4_4.Size = new System.Drawing.Size(21, 94);
            this.pbP4_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP4_4.TabIndex = 4;
            this.pbP4_4.TabStop = false;
            this.pbP4_4.Click += new System.EventHandler(this.pictureBox47_Click);
            // 
            // pbP4_3
            // 
            this.pbP4_3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP4_3.Location = new System.Drawing.Point(57, 3);
            this.pbP4_3.Name = "pbP4_3";
            this.pbP4_3.Size = new System.Drawing.Size(21, 94);
            this.pbP4_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP4_3.TabIndex = 3;
            this.pbP4_3.TabStop = false;
            this.pbP4_3.Click += new System.EventHandler(this.pictureBox46_Click);
            // 
            // pbP4_1
            // 
            this.pbP4_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP4_1.Location = new System.Drawing.Point(3, 3);
            this.pbP4_1.Name = "pbP4_1";
            this.pbP4_1.Size = new System.Drawing.Size(21, 94);
            this.pbP4_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP4_1.TabIndex = 2;
            this.pbP4_1.TabStop = false;
            this.pbP4_1.Click += new System.EventHandler(this.pictureBox45_Click);
            // 
            // pbP4_2
            // 
            this.pbP4_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbP4_2.Location = new System.Drawing.Point(30, 3);
            this.pbP4_2.Name = "pbP4_2";
            this.pbP4_2.Size = new System.Drawing.Size(21, 94);
            this.pbP4_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbP4_2.TabIndex = 1;
            this.pbP4_2.TabStop = false;
            this.pbP4_2.Click += new System.EventHandler(this.pictureBox44_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.tableLayoutPanel1);
            this.panel5.Location = new System.Drawing.Point(411, 234);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(281, 238);
            this.panel5.TabIndex = 16;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.Player2trick, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.Player3trick, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.mytrick, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.Player4trick, 1, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(281, 238);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // Player2trick
            // 
            this.Player2trick.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Player2trick.Location = new System.Drawing.Point(3, 3);
            this.Player2trick.Name = "Player2trick";
            this.Player2trick.Size = new System.Drawing.Size(134, 113);
            this.Player2trick.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Player2trick.TabIndex = 0;
            this.Player2trick.TabStop = false;
            // 
            // Player3trick
            // 
            this.Player3trick.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Player3trick.Location = new System.Drawing.Point(143, 3);
            this.Player3trick.Name = "Player3trick";
            this.Player3trick.Size = new System.Drawing.Size(135, 113);
            this.Player3trick.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Player3trick.TabIndex = 1;
            this.Player3trick.TabStop = false;
            // 
            // mytrick
            // 
            this.mytrick.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mytrick.Location = new System.Drawing.Point(3, 122);
            this.mytrick.Name = "mytrick";
            this.mytrick.Size = new System.Drawing.Size(134, 113);
            this.mytrick.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.mytrick.TabIndex = 2;
            this.mytrick.TabStop = false;
            // 
            // Player4trick
            // 
            this.Player4trick.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Player4trick.Location = new System.Drawing.Point(143, 122);
            this.Player4trick.Name = "Player4trick";
            this.Player4trick.Size = new System.Drawing.Size(135, 113);
            this.Player4trick.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Player4trick.TabIndex = 3;
            this.Player4trick.TabStop = false;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.Deck);
            this.panel6.Location = new System.Drawing.Point(278, 349);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(110, 148);
            this.panel6.TabIndex = 17;
            // 
            // Deck
            // 
            this.Deck.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Deck.Image = global::HeartsGame.Properties.Resources.card_back;
            this.Deck.Location = new System.Drawing.Point(0, 0);
            this.Deck.Name = "Deck";
            this.Deck.Size = new System.Drawing.Size(110, 148);
            this.Deck.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Deck.TabIndex = 0;
            this.Deck.TabStop = false;
            this.Deck.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::HeartsGame.Properties.Resources.Player;
            this.pictureBox4.Location = new System.Drawing.Point(987, 317);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(100, 50);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 3;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::HeartsGame.Properties.Resources.Player;
            this.pictureBox3.Location = new System.Drawing.Point(507, 12);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(100, 50);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::HeartsGame.Properties.Resources.Player;
            this.pictureBox2.Location = new System.Drawing.Point(12, 296);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::HeartsGame.Properties.Resources.Player;
            this.pictureBox1.Location = new System.Drawing.Point(507, 663);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // restartButton
            // 
            this.restartButton.Font = new System.Drawing.Font("Tw Cen MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.restartButton.Location = new System.Drawing.Point(37, 39);
            this.restartButton.Name = "restartButton";
            this.restartButton.Size = new System.Drawing.Size(100, 34);
            this.restartButton.TabIndex = 18;
            this.restartButton.Text = "Start";
            this.restartButton.UseVisualStyleBackColor = true;
            this.restartButton.Click += new System.EventHandler(this.restartButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(1099, 725);
            this.Controls.Add(this.restartButton);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel_P4);
            this.Controls.Add(this.panel_P1);
            this.Controls.Add(this.panel_P2);
            this.Controls.Add(this.panel_P3);
            this.Controls.Add(this.Player4_Score);
            this.Controls.Add(this.Player3_Score);
            this.Controls.Add(this.Player2_Score);
            this.Controls.Add(this.My_Score);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.ForeColor = System.Drawing.Color.Blue;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1117, 772);
            this.MinimumSize = new System.Drawing.Size(1117, 772);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Heart Game";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel_P3.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbP3_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP3_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP3_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP3_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP3_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP3_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP3_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP3_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP3_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP3_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP3_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP3_12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP3_13)).EndInit();
            this.panel_P2.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbP2_12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP2_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP2_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP2_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP2_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP2_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP2_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP2_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP2_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP2_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP2_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP2_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP2_13)).EndInit();
            this.panel_P1.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbMe13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMe12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMe11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMe10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMe9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMe8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMe7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMe6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMe5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMe4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMe3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMe2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMe1)).EndInit();
            this.panel_P4.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbP4_13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP4_12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP4_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP4_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP4_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP4_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP4_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP4_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP4_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP4_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP4_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP4_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbP4_2)).EndInit();
            this.panel5.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Player2trick)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Player3trick)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mytrick)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Player4trick)).EndInit();
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Deck)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label My_Score;
        private System.Windows.Forms.Label Player2_Score;
        private System.Windows.Forms.Label Player3_Score;
        private System.Windows.Forms.Label Player4_Score;
        private System.Windows.Forms.Panel panel_P3;
        private System.Windows.Forms.Panel panel_P2;
        private System.Windows.Forms.Panel panel_P1;
        private System.Windows.Forms.Panel panel_P4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.PictureBox Player2trick;
        private System.Windows.Forms.PictureBox Player3trick;
        private System.Windows.Forms.PictureBox mytrick;
        private System.Windows.Forms.PictureBox Player4trick;
        private System.Windows.Forms.PictureBox Deck;
        private System.Windows.Forms.PictureBox pbP3_1;
        private System.Windows.Forms.PictureBox pbP3_2;
        private System.Windows.Forms.PictureBox pbP3_3;
        private System.Windows.Forms.PictureBox pbP3_4;
        private System.Windows.Forms.PictureBox pbP3_5;
        private System.Windows.Forms.PictureBox pbP3_6;
        private System.Windows.Forms.PictureBox pbP3_7;
        private System.Windows.Forms.PictureBox pbP3_8;
        private System.Windows.Forms.PictureBox pbP3_9;
        private System.Windows.Forms.PictureBox pbP3_10;
        private System.Windows.Forms.PictureBox pbP3_11;
        private System.Windows.Forms.PictureBox pbP3_12;
        private System.Windows.Forms.PictureBox pbP3_13;
        private System.Windows.Forms.PictureBox pbP2_12;
        private System.Windows.Forms.PictureBox pbP2_11;
        private System.Windows.Forms.PictureBox pbP2_10;
        private System.Windows.Forms.PictureBox pbP2_9;
        private System.Windows.Forms.PictureBox pbP2_8;
        private System.Windows.Forms.PictureBox pbP2_7;
        private System.Windows.Forms.PictureBox pbP2_6;
        private System.Windows.Forms.PictureBox pbP2_5;
        private System.Windows.Forms.PictureBox pbP2_4;
        private System.Windows.Forms.PictureBox pbP2_3;
        private System.Windows.Forms.PictureBox pbP2_2;
        private System.Windows.Forms.PictureBox pbP2_1;
        private System.Windows.Forms.PictureBox pbP2_13;
        private System.Windows.Forms.PictureBox pbMe13;
        private System.Windows.Forms.PictureBox pbMe12;
        private System.Windows.Forms.PictureBox pbMe11;
        private System.Windows.Forms.PictureBox pbMe10;
        private System.Windows.Forms.PictureBox pbMe9;
        private System.Windows.Forms.PictureBox pbMe8;
        private System.Windows.Forms.PictureBox pbMe7;
        private System.Windows.Forms.PictureBox pbMe6;
        private System.Windows.Forms.PictureBox pbMe5;
        private System.Windows.Forms.PictureBox pbMe4;
        private System.Windows.Forms.PictureBox pbMe3;
        private System.Windows.Forms.PictureBox pbMe2;
        private System.Windows.Forms.PictureBox pbMe1;
        private System.Windows.Forms.PictureBox pbP4_13;
        private System.Windows.Forms.PictureBox pbP4_12;
        private System.Windows.Forms.PictureBox pbP4_11;
        private System.Windows.Forms.PictureBox pbP4_10;
        private System.Windows.Forms.PictureBox pbP4_9;
        private System.Windows.Forms.PictureBox pbP4_8;
        private System.Windows.Forms.PictureBox pbP4_7;
        private System.Windows.Forms.PictureBox pbP4_6;
        private System.Windows.Forms.PictureBox pbP4_5;
        private System.Windows.Forms.PictureBox pbP4_4;
        private System.Windows.Forms.PictureBox pbP4_3;
        private System.Windows.Forms.PictureBox pbP4_1;
        private System.Windows.Forms.PictureBox pbP4_2;
        private System.Windows.Forms.Button restartButton;
    }
}

